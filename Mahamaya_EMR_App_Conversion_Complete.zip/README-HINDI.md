# Shri Krishna Mahamaya EMR — App Conversion Package

इस package में दो तैयार भाग हैं:

1. `pwa/` — मौजूदा GitHub Pages website को installable PWA बनाने के files.
2. `android/` — Android Studio/GitHub Actions से APK बनाने वाला WebView project.

पहले PWA files अपनी वर्तमान EMR repository में जोड़ें। Android project अलग repository में रखना अधिक सुरक्षित और साफ रहेगा।
