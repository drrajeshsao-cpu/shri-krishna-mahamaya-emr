# Mahamaya EMR Android App

यह Android WebView app आपकी live GitHub Pages EMR website खोलता है:

`https://drrajeshsao-cpu.github.io/shri-krishna-mahamaya-emr/`

## Android Studio से APK
1. `android` folder Android Studio में खोलें।
2. Gradle sync पूरा होने दें।
3. Build → Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions से APK (मोबाइल से आसान)
1. इस `android` folder की पूरी सामग्री एक नई GitHub repository में upload करें।
2. Repository → Actions → **Build Android APK**.
3. Run workflow दबाएँ।
4. Build पूरा होने पर Artifacts में `Mahamaya-EMR-debug-APK` download करें।
5. ZIP खोलकर `app-debug.apk` install करें।

## Data note
यह app WebView storage का उपयोग करता है। यह Chrome browser के localStorage से अलग हो सकता है।
पहली बार app उपयोग करने से पहले browser वाले EMR से backup export करें और app में restore करें, यदि आपके software में backup/restore सुविधा उपलब्ध है।

## Security
- Default PIN तुरंत बदलें।
- Patient-identifiable data public GitHub repository में upload न करें।
- नियमित encrypted/off-device backup रखें।
