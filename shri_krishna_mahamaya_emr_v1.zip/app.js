
const STORAGE_PREFIX = "skm-emr-v1:";
function el(id){ return document.getElementById(id); }
function value(id){ return el(id)?.value?.trim() ?? ""; }
function setValue(id,v){ if(el(id)) el(id).value = v ?? ""; }
function today(){ return new Date().toISOString().slice(0,10); }
function makeId(){
  return "SKM-" + Date.now().toString(36).toUpperCase() + "-" +
    Math.random().toString(36).slice(2,6).toUpperCase();
}
function makeUHID(){
  return "SKM-" + new Date().getFullYear() + "-" + String(Date.now()).slice(-7);
}
function showStatus(message,isError=false){
  const s=el("status");
  if(!s) return;
  s.textContent=message;
  s.style.borderColor=isError ? "#d88" : "#9bcdb0";
  s.style.background=isError ? "#fff0ef" : "#f3faf6";
  s.style.color=isError ? "#8a2018" : "#245e3d";
}
function patientKey(id){ return STORAGE_PREFIX + id; }
function savePatient(record){
  localStorage.setItem(patientKey(record.id), JSON.stringify(record));
}
function loadPatient(id){
  const raw=localStorage.getItem(patientKey(id));
  return raw ? JSON.parse(raw) : null;
}
function loadAllPatients(){
  const rows=[];
  for(let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i);
    if(k && k.startsWith(STORAGE_PREFIX)){
      try{ rows.push(JSON.parse(localStorage.getItem(k))); }catch{}
    }
  }
  return rows.sort((a,b)=>(b.updatedAt||"").localeCompare(a.updatedAt||""));
}
function deletePatient(id){ localStorage.removeItem(patientKey(id)); }
function queryParam(name){ return new URLSearchParams(location.search).get(name); }
function escapeHtml(s){
  return String(s ?? "").replace(/[&<>"']/g,m=>({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[m]));
}
