let diseases=[];
const grid=document.getElementById('diseaseGrid');
const search=document.getElementById('search');
const statusFilter=document.getElementById('statusFilter');
const stats=document.getElementById('stats');
const dialog=document.getElementById('diseaseDialog');
const detail=document.getElementById('diseaseDetail');

afterLoad();
async function afterLoad(){
  diseases=await fetch('./data/diseases.json').then(r=>r.json());
  render();
}
function render(){
  const q=search.value.trim().toLowerCase();
  const sf=statusFilter.value;
  const filtered=diseases.filter(d=>{
    const hay=(d.id+' '+d.name+' '+d.summary+' '+d.modules.join(' ')).toLowerCase();
    return (!q||hay.includes(q))&&(sf==='all'||d.status===sf);
  });
  const ready=diseases.filter(d=>d.status==='ready').length;
  stats.innerHTML=`<div class="stat"><b>${diseases.length}</b> disease slots</div><div class="stat"><b>${ready}</b> verified titles</div><div class="stat"><b>${diseases.length-ready}</b> import pending</div>`;
  grid.innerHTML=filtered.map(d=>`<article class="card" data-id="${d.id}" tabindex="0">
    <span class="badge ${d.status}">${d.status==='ready'?'Content slot ready':'Import pending'}</span>
    <h3>${escapeHtml(d.name)}</h3><div class="meta">${d.id}</div>
    <p>${escapeHtml(d.summary)}</p>
  </article>`).join('')||'<p>कोई परिणाम नहीं मिला।</p>';
  document.querySelectorAll('.card').forEach(c=>{
    c.onclick=()=>openDisease(c.dataset.id);
    c.onkeydown=e=>{if(e.key==='Enter')openDisease(c.dataset.id)};
  });
}
function openDisease(id){
  const d=diseases.find(x=>x.id===id);
  detail.innerHTML=`<div class="detail"><div class="meta">${d.id}</div><h2>${escapeHtml(d.name)}</h2>
  <p>${escapeHtml(d.summary)}</p>
  ${d.status==='pending'?'<p class="notice"><b>Import pending:</b> इस Disease ID का मूल शीर्षक और A–T module content master manuscript से जोड़ना आवश्यक है।</p>':''}
  <section><h3>Available module structure</h3>${d.modules.length?`<ul class="modules">${d.modules.map(m=>`<li>${escapeHtml(m)}</li>`).join('')}</ul>`:'<p>Content not imported yet.</p>'}</section>
  <section><h3>Clinical safety</h3><p>यह सामग्री Clinical Decision Support के लिए है। Emergency red flags और specialist referral को प्राथमिकता दें।</p></section></div>`;
  dialog.showModal();
}
function escapeHtml(s){return s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
search.addEventListener('input',render);statusFilter.addEventListener('change',render);
document.getElementById('closeDialog').onclick=()=>dialog.close();

let deferredPrompt;const installBtn=document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false});
installBtn.onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true};
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js'));
